resource "aws_security_group" "bastion_sg" {
  name        = "${var.prefix}-bastion-sg"
  description = "Security group for the Bastion host"
  vpc_id      = var.vpc_id

  ingress {
    description = "SSH access"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.allowed_cidrs
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(
    var.tags,
    {
      Name = "${var.prefix}-jenkins-bastion-sg"
  })
}

resource "aws_instance" "bastion" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [aws_security_group.bastion_sg.id]

  key_name = var.key_pair_name

  root_block_device {
    volume_type = "gp3"
    volume_size = 10
  }

  tags = merge(
    var.tags,
    {
      Name = "${var.prefix}-jenkins-bastion"
  })
}

resource "aws_security_group_rule" "bastion_to_jenkins_ssh" {
  type                     = "ingress"
  from_port                = 22
  to_port                  = 22
  protocol                 = "tcp"
  security_group_id        = var.jenkins_sg_id
  source_security_group_id = aws_security_group.bastion_sg.id

  description = "Allow SSH from Bastion to Jenkins"
}