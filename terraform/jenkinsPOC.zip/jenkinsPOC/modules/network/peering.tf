# Data source to get the VPC information for the Rancher VPC
data "aws_vpc" "rancher_vpc" {
  tags = {
    Name = "folio-rancher-vpc"
  }
}

# Data source to get the private route table for the Rancher VPC
data "aws_route_table" "rancher_private_rt" {
  tags = {
    Name = "folio-rancher-vpc-private"
  }
}

# Data source to get the public route table for the Rancher VPC
data "aws_route_table" "rancher_public_rt" {
  tags = {
    Name = "folio-rancher-vpc-public"
  }
}

# Resource to create a VPC peering connection between the Jenkins VPC and the Rancher VPC
resource "aws_vpc_peering_connection" "this" {
  vpc_id      = aws_vpc.this.id
  peer_vpc_id = data.aws_vpc.rancher_vpc.id
  auto_accept = true

  tags = merge(
    var.tags,
    {
      Name = "${var.prefix}-jenkins-peering"
  })
}

# Resource to accept the VPC peering connection from the Rancher VPC side
resource "aws_vpc_peering_connection_accepter" "rancher_accepts" {
  depends_on                = [aws_vpc_peering_connection.this]
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  auto_accept               = true

  tags = merge(
    var.tags,
    {
      Name = "${var.prefix}-jenkins-peering-accepter"
  })
}

# Resource to create a route in the Jenkins public route table to the Rancher VPC
resource "aws_route" "jenkins_public_to_rancher" {
  route_table_id            = aws_route_table.public_rt.id
  destination_cidr_block    = data.aws_vpc.rancher_vpc.cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  depends_on                = [aws_vpc_peering_connection_accepter.rancher_accepts]
}

# Resource to create a route in the Jenkins private route table to the Rancher VPC
resource "aws_route" "jenkins_private_to_rancher" {
  route_table_id            = aws_route_table.private_rt.id
  destination_cidr_block    = data.aws_vpc.rancher_vpc.cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  depends_on                = [aws_vpc_peering_connection_accepter.rancher_accepts]
}

# Resource to create a route in the Rancher private route table to the Jenkins VPC
resource "aws_route" "rancher_private_to_jenkins_vpc" {
  route_table_id            = data.aws_route_table.rancher_private_rt.id
  destination_cidr_block    = var.vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  depends_on                = [aws_vpc_peering_connection_accepter.rancher_accepts]
}

# Resource to create a route in the Rancher public route table to the Jenkins VPC
resource "aws_route" "rancher_public_to_jenkins_vpc" {
  route_table_id            = data.aws_route_table.rancher_public_rt.id
  destination_cidr_block    = var.vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.this.id
  depends_on                = [aws_vpc_peering_connection_accepter.rancher_accepts]
}