output "vpc_id" {
  description = "ID of the new VPC."
  value       = aws_vpc.this.id
}

output "public_subnet_id" {
  description = "ID of the public subnet."
  value       = aws_subnet.public_subnet.id
}

output "private_subnet_id" {
  description = "ID of the private subnet."
  value       = aws_subnet.private_subnet.id
}

output "vpc_peering_connection_id" {
  description = "VPC Peering Connection ID between the new VPC and Rancher VPC."
  value       = aws_vpc_peering_connection.this.id
}