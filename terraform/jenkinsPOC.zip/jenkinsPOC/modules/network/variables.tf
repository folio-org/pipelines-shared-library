variable "prefix" {
  type        = string
  description = "Name prefix for tagging and resource naming."
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR block for the new VPC."
}

variable "public_subnet_cidr" {
  type        = string
  description = "CIDR block for the public subnet."
}

variable "private_subnet_cidr" {
  type        = string
  description = "CIDR block for the private subnet."
}

variable "availability_zone" {
  type        = string
  description = "The single AZ to place both subnets in."
}

variable "aws_region" {
  type        = string
  description = "AWS region."
}

variable "tags" {
  type        = map(any)
  default     = {}
  description = "Default tags"
}